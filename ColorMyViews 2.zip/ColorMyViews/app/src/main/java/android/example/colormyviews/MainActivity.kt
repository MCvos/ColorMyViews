package android.example.colormyviews

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ListView
//import kotlinx.android.synthetic.main.activity_main.box_five_text
//import kotlinx.android.synthetic.main.activity_main.box_four_text
//import kotlinx.android.synthetic.main.activity_main.box_one_text
//import kotlinx.android.synthetic.main.activity_main.box_three_text
//import kotlinx.android.synthetic.main.activity_main.box_two_text
//import kotlinx.android.synthetic.main.activity_main.constraint_layout

class MainActivity : AppCompatActivity() {

    private lateinit var binding:ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setListeners()

    }
    private fun setListeners() {
        val clickableViews: List<View> =
                listOf(binding.box_one_text, binding.box_two_text, binding.box_three_text,
                    binding.box_four_text, binding.box_five_text, binding.constraint_layout)

        for (item in clickableViews) {
            item.setOnClickListener { makeColored(it)}
        }
    }

    private
    fun makeColored(view: View) {
        when (view.id)  {

            R.id.box_one_text -> view.setBackgroundColor(Color.DKGRAY)
            R.id.box_two_text -> view.setBackgroundColor(Color.GRAY)

            R.id.box_three_text -> view.setBackgroundColor(Color.CYAN)
            R.id.box_four_text -> view.setBackgroundColor(Color.YELLOW)
            R.id.box_five_text -> view.setBackgroundColor(Color.MAGENTA)

            else -> view.setBackgroundColor(Color.LTGRAY)
        }
    }
}